#!/bin/bash

## input legal check
if [[ ! -d "$1" ]]; then
	exit 1
fi

currDir=`pwd`
cd "$1" ##change directory to parameter dir
## c++ compiler
echo "CXX=g++" > "${currDir}"/objects.mk
## c++ flags for compiler
echo "CXXFLAGS=-std=c++11 -g -Wall" >> "${currDir}"/objects.mk
## libs for compiler
echo -e "LIBS=\n\n" >> "${currDir}"/objects.mk

c=`ls -1` ## list of all files in dir
for file in "${c}"; do
	filename="${file}" ## keep file name
	a=`echo "${filename}" | grep -E '\.cpp$'` ## find cpp files
	if [[ ! a ]]; then ## if not cpp file, skip it
		continue
	fi
	b=`g++ -MM ${a}` ## get dependencies list of cpp file
	echo -e "${b}\n\n" >> "${currDir}"/objects.mk ## print the output to the make file
done

cd "${currDir}"