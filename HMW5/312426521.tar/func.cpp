/*

  File: func.cpp

  Abstract:

    Func handling implementation

*/
#include "func.h"

/*
  Function Name	:	func
  Description	:	The constructor of func (without parameters),
                    which only initializes maxVal and minVal
  Parameters	:	None.
  Return Value	:	Instantiation of func class.
  */
func::func() :
    maxVal_(minusInf),
    minVal_(Inf) {
    }

/*
  Function Name	:	~func
  Description	:   Destructor of func object.
  Parameters	:	None.
  Return Value	:	None.
  */

func::~func() {
    pass;
}

/*
  Function Name	:	func
  Description	:	Copy constructor of func object
                    which assigns maxVal and minVal
                    according to the copied func
  Parameters	:	function - func object to copy.
  Return Value	:	Instantiation of func class.
  */

func::func(const func& function): 
    maxVal_(function.maxVal_),
    minVal_(function.minVal_) {
}

/*
  Function Name	:	plot
  Description	:   plots f(x): creates an axis for
                    x and for y and adds a star (*) wherever
                    f(x) = y  
  Parameters	:	os  - output ostream object to print to.
  Return Value	:	None.
  */

void func::plot(ostream& os) const {

  vector<int> sortImage;
    

  //Firstly, we shall insert into the vector sortImage
  //All of the dots in the map, and then sort them
  sortImage.clear();
  for ( auto it : fmap_){
      sortImage.push_back(it.second); 
  }

  sort(sortImage.begin(), sortImage.end());
  reverse(sortImage.begin(), sortImage.end());
  
  for ( auto it_im = sortImage.begin();
       it_im != sortImage.end(); ++it_im) {
    if(it_im!=sortImage.begin() && *it_im==*(it_im-1)){ //remove repeated
      it_im = sortImage.erase(it_im)-1;
      
    }
  }
 
  //Secondly, we shall iterate over the vector
  //and "plot" as described on the brief each pair

  for (auto it_im = sortImage.begin();
       it_im != sortImage.end(); ++it_im) {
    int x_anchor=minVal_;
    if(*it_im<-9) 
      os <<*it_im;
    else
      if((*it_im<0) || (*it_im>9)) 
	os<<" "<<*it_im;
      else 
	os<<"  "<<*it_im;
    
    for (auto it_dom : fmap_) {
      if(it_dom.second == *it_im){
	int x=it_dom.first;
	int spaces= x-x_anchor;
	int i=0;
	while(i<spaces){
	  os<<"   ";
	  i++;
	}
	os<<"*  ";
	x_anchor=x+1;
      }

    }

    os<< endl ;
    if((it_im+1)!=sortImage.end()){ //print empty lines
      int lines=*it_im-*(it_im+1)-1;
      int i=1;
      
      while(i<lines+1){
	if(*it_im-i<-9) 
	  os <<*it_im-i;
	else 
	  if( (*it_im-i<0) || (*it_im-i>9) )
	    os<<" "<<*it_im-i;
	  else 
	    os<<"  "<<*it_im-i;
	cout<<endl;
	i++;

      }
    }

  }//for sortImage

  //print x axis
  cout<< " ";
  for (auto i=minVal_; i<maxVal_+1;i++){
    if(i<0) os<<" "<<i;
    else os<<"  "<<i;
  }
  os<<endl;
}

/*
  Function Name	:	operator<<
  Description	:   The input operator << which prints the
                    function to the standard output
  Parameters	:	os  - reference to output ostream object
                    f - reference to a func object
  Return Value	:	os
  */

ostream& operator<<(ostream& os, const func& f) {
    f.print(os);
    return os;

}